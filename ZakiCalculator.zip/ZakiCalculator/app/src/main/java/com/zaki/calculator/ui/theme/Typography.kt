package com.zaki.calculator.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()
