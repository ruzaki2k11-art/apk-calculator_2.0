package com.zaki.calculator

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    viewModel: CalculatorViewModel,
    onNavigateToSettings: () -> Unit
) {
    val result by viewModel.result
    val pendingOp by viewModel.pendingOperation
    val history = viewModel.history
    val scientificMode by viewModel.scientificMode
    val showHistory by viewModel.showHistory

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
    ) {
        // ── Top bar ──────────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF111111))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Zaki Calc",
                color = Color(0xFF4DA3FF),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 8.dp)
            )
            Row {
                TextButton(onClick = { viewModel.scientificMode.value = !scientificMode }) {
                    Text(
                        text = if (scientificMode) "STD" else "SCI",
                        color = if (scientificMode) Color(0xFF4DA3FF) else Color(0xFF666666),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(onClick = { viewModel.showHistory.value = !showHistory }) {
                    Icon(
                        Icons.Default.History,
                        contentDescription = "History",
                        tint = if (showHistory) Color(0xFF4DA3FF) else Color(0xFF666666)
                    )
                }
                IconButton(onClick = onNavigateToSettings) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color(0xFF666666))
                }
            }
        }

        Row(modifier = Modifier.weight(1f)) {
            // ── Calculator column ─────────────────────────────────
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                // Display
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.9f)
                        .background(Color(0xFF111111), RoundedCornerShape(16.dp))
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    contentAlignment = Alignment.BottomEnd
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        if (pendingOp.isNotEmpty()) {
                            Text(
                                text = "${viewModel.previousValue.toLong()} $pendingOp",
                                color = Color(0xFF555555),
                                fontSize = 18.sp
                            )
                        }
                        Text(
                            text = result,
                            color = Color.White,
                            fontSize = if (result.length > 12) 28.sp else if (result.length > 8) 38.sp else 50.sp,
                            fontWeight = FontWeight.Light,
                            textAlign = TextAlign.End,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Scientific buttons (animated)
                AnimatedVisibility(
                    visible = scientificMode,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    ScientificButtons(onClick = { viewModel.scientificCalculate(it) })
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // Standard button grid
                val buttonRows = listOf(
                    listOf("C",  "DEL", "%",  "÷"),
                    listOf("7",  "8",   "9",  "×"),
                    listOf("4",  "5",   "6",  "-"),
                    listOf("1",  "2",   "3",  "+"),
                    listOf("^",  "0",   ".",  "=")
                )

                buttonRows.forEach { row ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        row.forEach { label ->
                            CalcButton(
                                label = label,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    when (label) {
                                        "+", "-", "×", "÷", "%", "^" -> viewModel.setOperation(label)
                                        "=" -> viewModel.calculate()
                                        "C" -> viewModel.clear()
                                        "DEL" -> viewModel.delete()
                                        else -> viewModel.input(label)
                                    }
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
            }

            // ── History panel ─────────────────────────────────────
            AnimatedVisibility(
                visible = showHistory,
                enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
                exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .width(190.dp)
                        .fillMaxHeight()
                        .background(Color(0xFF121212))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("History", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        if (history.isNotEmpty()) {
                            IconButton(onClick = { viewModel.clearHistory() }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Clear", tint = Color(0xFF555555), modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    if (history.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No calculations yet", color = Color(0xFF444444), fontSize = 12.sp, textAlign = TextAlign.Center)
                        }
                    } else {
                        LazyColumn {
                            items(history) { item ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 6.dp)
                                        .clickable { viewModel.setFromHistory(item) },
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1C)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = item,
                                        modifier = Modifier.padding(8.dp),
                                        color = Color(0xFFAAAAAA),
                                        fontSize = 11.sp,
                                        maxLines = 3,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CalcButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val isOperator = label in listOf("+", "-", "×", "÷", "^", "%")
    val isEquals   = label == "="
    val isClear    = label == "C"
    val isDel      = label == "DEL"

    val bg = when {
        isEquals   -> Color(0xFF4DA3FF)
        isOperator -> Color(0xFF1A2E45)
        isClear    -> Color(0xFF2D1515)
        isDel      -> Color(0xFF1E1E1E)
        else       -> Color(0xFF1A1A1A)
    }
    val fg = when {
        isEquals   -> Color.White
        isOperator -> Color(0xFF4DA3FF)
        isClear    -> Color(0xFFFF6B6B)
        isDel      -> Color(0xFFFF9999)
        else       -> Color(0xFFE0E0E0)
    }

    Button(
        onClick = onClick,
        modifier = modifier.fillMaxHeight(),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = bg),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
        contentPadding = PaddingValues(0.dp)
    ) {
        Text(text = label, fontSize = 20.sp, fontWeight = FontWeight.Medium, color = fg)
    }
}
