package com.zaki.calculator

sealed class Screen(val route: String) {
    object Calculator : Screen("calculator")
    object Settings : Screen("settings")
}
