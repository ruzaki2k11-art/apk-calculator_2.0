package com.zaki.calculator

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zaki.calculator.database.HistoryDatabase
import com.zaki.calculator.database.HistoryEntity
import kotlinx.coroutines.launch
import kotlin.math.*

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val db = HistoryDatabase.getDatabase(application)
    private val dao = db.historyDao()

    var currentInput = mutableStateOf("")
    var result = mutableStateOf("0")
    var pendingOperation = mutableStateOf("")
    var previousValue = 0.0
    val history = mutableStateListOf<String>()
    var scientificMode = mutableStateOf(false)
    var showHistory = mutableStateOf(true)

    init {
        loadHistory()
    }

    private fun loadHistory() {
        viewModelScope.launch {
            val items = dao.getAll()
            history.clear()
            history.addAll(items.map { it.expression })
        }
    }

    fun input(value: String) {
        // Prevent multiple decimal points
        if (value == "." && currentInput.value.contains(".")) return
        currentInput.value += value
        result.value = currentInput.value
    }

    fun clear() {
        currentInput.value = ""
        result.value = "0"
        pendingOperation.value = ""
        previousValue = 0.0
    }

    fun delete() {
        if (currentInput.value.isNotEmpty()) {
            currentInput.value = currentInput.value.dropLast(1)
            result.value = currentInput.value.ifEmpty { "0" }
        }
    }

    fun setOperation(op: String) {
        previousValue = currentInput.value.toDoubleOrNull()
            ?: result.value.toDoubleOrNull()
            ?: 0.0
        pendingOperation.value = op
        currentInput.value = ""
    }

    fun calculate() {
        if (pendingOperation.value.isEmpty()) return
        val next = currentInput.value.toDoubleOrNull() ?: return
        val answer = when (pendingOperation.value) {
            "+" -> previousValue + next
            "-" -> previousValue - next
            "×" -> previousValue * next
            "÷" -> if (next == 0.0) Double.NaN else previousValue / next
            "%" -> previousValue % next
            "^" -> previousValue.pow(next)
            else -> next
        }
        val formattedAnswer = formatNumber(answer)
        val expression = "${formatNumber(previousValue)} ${pendingOperation.value} ${formatNumber(next)} = $formattedAnswer"
        saveHistory(expression)
        currentInput.value = formattedAnswer
        result.value = formattedAnswer
        pendingOperation.value = ""
    }

    fun scientificCalculate(func: String) {
        if (func == "π") {
            currentInput.value = Math.PI.toString()
            result.value = formatNumber(Math.PI)
            return
        }
        val value = currentInput.value.toDoubleOrNull()
            ?: result.value.toDoubleOrNull()
            ?: return
        val answer = when (func) {
            "sin"  -> sin(Math.toRadians(value))
            "cos"  -> cos(Math.toRadians(value))
            "tan"  -> tan(Math.toRadians(value))
            "log"  -> if (value > 0) log10(value) else Double.NaN
            "ln"   -> if (value > 0) ln(value) else Double.NaN
            "√"    -> if (value >= 0) sqrt(value) else Double.NaN
            "!"    -> { val n = value.toLong(); if (n in 0..20) factorial(n).toDouble() else Double.NaN }
            else   -> value
        }
        val formattedAnswer = if (answer.isNaN() || answer.isInfinite()) "Error" else formatNumber(answer)
        val expression = "$func(${formatNumber(value)}) = $formattedAnswer"
        saveHistory(expression)
        currentInput.value = formattedAnswer
        result.value = formattedAnswer
    }

    private fun saveHistory(expression: String) {
        history.add(0, expression)
        if (history.size > 50) history.removeAt(history.lastIndex)
        viewModelScope.launch {
            dao.insert(HistoryEntity(expression = expression))
        }
    }

    fun clearHistory() {
        history.clear()
        viewModelScope.launch { dao.clearAll() }
    }

    fun setFromHistory(expression: String) {
        val value = expression.substringAfterLast("=").trim()
        currentInput.value = value
        result.value = value
    }

    private fun formatNumber(n: Double): String {
        if (n.isNaN()) return "Error"
        if (n.isInfinite()) return "Infinity"
        return if (n == kotlin.math.floor(n) && !n.isInfinite()) n.toLong().toString()
        else n.toBigDecimal().stripTrailingZeros().toPlainString()
    }

    private fun factorial(n: Long): Long {
        if (n <= 1L) return 1L
        return n * factorial(n - 1L)
    }
}
