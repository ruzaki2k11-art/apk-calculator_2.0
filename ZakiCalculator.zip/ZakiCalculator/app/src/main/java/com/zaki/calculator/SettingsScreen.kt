package com.zaki.calculator

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    var vibration    by remember { mutableStateOf(true) }
    var sound        by remember { mutableStateOf(false) }
    var keepHistory  by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
    ) {
        TopAppBar(
            title = { Text("Settings", color = Color.White, fontWeight = FontWeight.Bold) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF111111))
        )

        Column(modifier = Modifier.padding(horizontal = 20.dp)) {
            Spacer(modifier = Modifier.height(8.dp))

            Text("Interface", color = Color(0xFF4DA3FF), fontSize = 13.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))

            SettingRow("Haptic Feedback", "Vibrate on button press", vibration) { vibration = it }
            HorizontalDivider(color = Color(0xFF1E1E1E))
            SettingRow("Button Sounds", "Play click sounds", sound) { sound = it }

            Spacer(modifier = Modifier.height(16.dp))
            Text("History", color = Color(0xFF4DA3FF), fontSize = 13.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
            SettingRow("Persistent History", "Save history between sessions", keepHistory) { keepHistory = it }

            Spacer(modifier = Modifier.height(24.dp))
            Text("App Version 1.0", color = Color(0xFF333333), fontSize = 12.sp,
                modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
fun SettingRow(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Color(0xFF666666), fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF4DA3FF),
                uncheckedThumbColor = Color(0xFF444444),
                uncheckedTrackColor = Color(0xFF222222)
            )
        )
    }
}
