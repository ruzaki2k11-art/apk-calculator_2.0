package com.zaki.calculator.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary          = Color(0xFF4DA3FF),
    secondary        = Color(0xFF1E3A5F),
    background       = Color(0xFF000000),
    surface          = Color(0xFF121212),
    onPrimary        = Color.White,
    onBackground     = Color.White,
    onSurface        = Color.White,
    onSecondary      = Color.White
)

@Composable
fun CalculatorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography  = Typography,
        content     = content
    )
}
