# Zaki Calculator — Android App

A modern Material 3 Android calculator with dark/AMOLED theme, history, and scientific mode.

## Features
- AMOLED dark theme with blue accent
- Scientific mode: sin, cos, tan, log, ln, √, !, π
- Persistent calculation history (Room database)
- MVVM architecture with Jetpack ViewModel
- Smooth animations with AnimatedVisibility
- Settings screen (vibration, sound, history toggle)
- Navigation with Jetpack Navigation Compose

## How to Build APK

### Requirements
- Android Studio (Hedgehog 2023.1.1 or newer)
- JDK 17+ (bundled with Android Studio)
- Android SDK 34 (install via SDK Manager in Android Studio)

### Steps
1. Open Android Studio
2. Click **File → Open** and select this `ZakiCalculator` folder
3. Wait for Gradle sync to finish (it downloads dependencies automatically)
4. Click **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

### Install to Phone
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```
Or just tap the APK file on your phone after copying it over.

---

## Project Structure
```
ZakiCalculator/
├── app/src/main/
│   ├── java/com/zaki/calculator/
│   │   ├── MainActivity.kt          — Entry point
│   │   ├── AppNavigation.kt         — Jetpack Navigation setup
│   │   ├── Screen.kt                — Route definitions
│   │   ├── CalculatorViewModel.kt   — Business logic + state (MVVM)
│   │   ├── CalculatorScreen.kt      — Main calculator UI
│   │   ├── ScientificButtons.kt     — sin/cos/tan/etc buttons
│   │   ├── SettingsScreen.kt        — Settings page
│   │   └── database/                — Room persistence
│   │       ├── HistoryDatabase.kt
│   │       ├── HistoryDao.kt
│   │       └── HistoryEntity.kt
│   │   └── ui/theme/
│   │       ├── Theme.kt             — AMOLED dark color scheme
│   │       └── Typography.kt
│   └── AndroidManifest.xml
├── app/build.gradle                 — Dependencies
├── settings.gradle
└── README.md
```
